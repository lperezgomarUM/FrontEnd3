export const titleStyles = { 
    width: 80, 
    margin: '10px', 
    color: 'green', 
    backgroundColor: 'white'
}